/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import java.net.Socket;
import javax.swing.JOptionPane;
import java.util.Scanner;

/**
 *
 */
public class ClientEnd {
	


	public static UserFiles Input()
	{
		Scanner sc = new Scanner(System.in);

		System.out.println("Select the Operation:\n 1: New Record \n 2: Search Record");

		int operation = Integer.parseInt(sc.nextLine());
		System.out.println("Type username: ");
		String username = sc.nextLine();
		UserFiles newRec;
		
		if(operation == 1)
		{
			System.out.println("Type the notes: ");
			
			String notes = sc.nextLine();
			newRec = new UserFiles(username,notes,1);

		}
		else
		{
			newRec = new UserFiles(username,"",2);
		}
		return newRec;
	}



	public static void main(String[] args) 
	{
		try
		{	
			Socket sender = new Socket("localhost",8001);
			UserFiles newRec = Input();
			ObjectOutputStream outServer = new ObjectOutputStream(sender.getOutputStream());
			ObjectInputStream inServer = new ObjectInputStream(sender.getInputStream());
			
			outServer.writeObject(newRec);

			if(newRec.operation == 2)
			{
				while(true)
				{
					UserFiles newRec1 = (UserFiles)inServer.readObject();
					System.out.println("User Found: ");
					System.out.println("User Name: "+newRec1.Username);
					System.out.println("Notes : "+ newRec1.Notes);
				}
			}

			sender.close();   
		}
		catch(Exception e)
		{
			System.out.println("Exception");
			System.out.println(e.getMessage());
		}
	}

}
