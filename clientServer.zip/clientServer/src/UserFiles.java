


public class UserFiles implements java.io.Serializable
{
    public String Username;
    public String Notes;
    public int operation;
    
    public UserFiles(String user,String note, int oper)
    {
        Username = user ;
        Notes = note;
        operation = oper;
    }
    
    
    public String getUser()
    {
        return Username;
    }
    
    public String getNotes()
    {
        return Notes;
    }
    
}
