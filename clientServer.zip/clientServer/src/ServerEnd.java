/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;


/**
 *
 */
public class ServerEnd {


	public static void main(String[] args)
	{
		ServerSocket listen = null;
		try{
			ArrayList<UserFiles> list = new ArrayList<UserFiles>();
			listen = new ServerSocket(8001);
			while(true)
			{
				Socket socket = listen.accept();
				ObjectOutputStream  output = new ObjectOutputStream (socket.getOutputStream());
				ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
				UserFiles newRecord;
				newRecord = (UserFiles)input.readObject();

				if(newRecord.operation == 1){
					list.add(newRecord);
					System.out.println("Server Got: ");
					System.out.println("User: " + newRecord.Username);
					System.out.println("Notes: " + newRecord.Notes);
				}
				else
				{
					for(int i = 0; i < list.size();i++)
					{
						if(list.get(i).Username.equals(newRecord.Username))
						{
							output.writeObject(list.get(i));
						}
						else {
							System.out.println("User Not Found!");
						}
					}


				}




			}

		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}


	}

}
